//
//  AferoSofthub.h
//  AferoSofthub
//
//  Created by Justin Middleton on 10/31/17.
//  Copyright © 2017 Stephen Sewerynek. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AferoSofthub.
FOUNDATION_EXPORT double AferoSofthubVersionNumber;

//! Project version string for AferoSofthub.
FOUNDATION_EXPORT const unsigned char AferoSofthubVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AferoSofthub/PublicHeader.h>

#import <AferoSofthub/AferoSofthubWrapper.h>
